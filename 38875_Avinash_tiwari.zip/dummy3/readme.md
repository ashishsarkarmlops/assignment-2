1)install all the dependuncies from requirement.txt by clicking following command
=>pip install -r requirements.txt

2)Then run the follwing command from the project directory
=>python manage.py runserver

3)Open follwoing url once server starts.
=>http://localhost:8000/

4)Login information
=>Username: avinash_tiwari
=>Passward: admin@123

For database use following url and use the same Username and Password:
http://localhost:8000/admin
